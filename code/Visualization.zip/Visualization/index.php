<?php 
	session_start();
	require_once 'php/google-api-php-client/vendor/autoload.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Vic Roads Analytics</title>
	<meta charset='UTF-8'>
	<link href='https://fonts.googleapis.com/css?family=Cabin' rel='stylesheet' type='text/css'>
	<link rel='stylesheet' type='text/css' href='/css/style.css'>
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Type', 'Numbers of Accidents'],
          ['Collision', 159958],
          ['Ran off carriageway', 32453], 
          ['Fell from vehicle', 26605],
          ['Rollover on/off carriageway', 12289], 
          ['Other', 1595], 
        ]);
        var options = {
          title: 'Accidents Types'
        };
        var chart = new google.visualization.PieChart(document.getElementById('piechart'));
        chart.draw(data, options); }
    </script>
    <script type="text/javascript">
    google.charts.load('current', {packages: ['corechart', 'bar']});
	google.charts.setOnLoadCallback(drawBasic);
	function drawBasic() {
      var data = google.visualization.arrayToDataTable([
        ['Age', 'Count'],
        ['Not Known', 16315],
        ['18', 11313],
        ['19', 10835],
        ['20', 10205],
        ['21', 9797],
        ['22', 9550],
        ['23', 9272],
        ['24', 8949],
        ['25', 8494],
        ['26', 8087],
        ['27', 7824],
        ['28', 7375]
      ]);

      var options = {
        title: 'Age Causing Most Accidents',
        chartArea: {width: '30%'},
      };
      var chart = new google.visualization.BarChart(document.getElementById('ageChart'));
      chart.draw(data, options);
   	 }
		</script>	
		
	<script type="text/javascript">
	  google.charts.load('current', {packages:['table']});
      google.charts.setOnLoadCallback(drawTable);
      function drawTable() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Name');
        data.addColumn('number', 'Count');
        data.addRows([
          ['METROPOLITAN RING ROAD btwn METROPOLITAN RING ROAD Offramp & WESTERN RING ROAD',  3355000],
          ['METROPOLITAN RING ROAD btwn HUME FREEWAY & COBURG-CRAIGIEBURN ROAD',   3355000],
          ['METROPOLITAN RING ROAD btwn HUME FWY & EDGARS RD', 3172000],
          ['METROPOLITAN RING ROAD btwn METROPOLITAN RING ROAD Offramp & METROPOLITAN RING ROAD Onramp',   2765333],
          ['METROPOLITAN RING ROAD btwn METROPOLITAN RING ROAD Onramp & METROPOLITAN RING ROAD Offramp',   2623000]
        ]);
        var table = new google.visualization.Table(document.getElementById('vehicleCount'));
        table.draw(data, {showRowNumber: true, width: '100%', height: '100%'});
      }	
      </script>
	<script type="text/javascript">
	  google.charts.load('current', {packages:['table']});
      google.charts.setOnLoadCallback(drawTable);
      function drawTable() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Name');
        data.addColumn('number', 'Count');
        data.addRows([
          ['MELBOURNE',  9830],
          ['CASEY',   6021],
          ['DANDENONG', 5264],
          ['GEELONG',   5174],
          ['BRIMBANK',   4797]
        ]);
        var table = new google.visualization.Table(document.getElementById('DangerousArea'));
        table.draw(data, {showRowNumber: true, width: '100%', height: '100%'});
      }	
    </script>
    <script type="text/javascript">
    google.charts.load('current', {packages: ['corechart', 'line']});
google.charts.setOnLoadCallback(drawBasic);

function drawBasic() {

      var data = new google.visualization.DataTable();
      data.addColumn('number', 'X');
      data.addColumn('number', 'Dogs');

      data.addRows([
        [0, 2319],   [1, 1997],  [2, 1626],  [3, 1491],  [4, 1287],  [5, 1954],
        [6, 4218],  [7, 6269],  [8, 9882],  [9, 7765],  [10, 7473], [11, 8489],
        [12, 8947], [13, 8722], [14, 8956], [15, 11846], [16, 11888], [17, 12347],
        [18, 10240], [19, 6390], [20, 4606], [21, 4271], [22, 3631], [23, 3066]
      ]);

      var options = {
        hAxis: {
          title: 'Time'
        },
        vAxis: {
          title: 'Count'
        }
      };

      var chart = new google.visualization.LineChart(document.getElementById('DangerousTime'));

      chart.draw(data, options);
    }
</script>
		
</head>
<body>
	<header>
		<br><div id='vicroads'>Vic Roads Analytics</div>
	</header>
	<main>
		<h><a style='font-size:24px' href="https://datastudio.google.com/open/0ByLdmFPGXlUFbmJDdFhiR0pjT0E">View full results in data visualization by click this link.</a></h>
		<div id="piechart" style="width: 900px; height: 500px;"></div>
		<div id="ageChart" style="width: 900px; height: 500px;"></div>
        <div id="vehicleCount"></div>
        <div id="DangerousArea"></div>
        <div id="FreewayFlows"></div>
        <div id="DangerousTime"></div>

		<?php
		$client = new Google_Client();
		$client->useApplicationDefaultCredentials();
		$client->addScope(Google_Service_Bigquery::BIGQUERY);
		$bigquery = new Google_Service_Bigquery($client);
		$projectId = 's3583185-bigquery';
		$request = new Google_Service_Bigquery_QueryRequest();
		
		
		$request->setQuery("SELECT Area, Accidents_Count as Count FROM [assignment2.accidents_in_area] ORDER BY Count DESC LIMIT 5;");
		$response = $bigquery->jobs->query($projectId, $request);
		$rows = $response->getRows();
		$str3 = "<div id='t3'><table style='width:100%' border=1 cellpadding=10>"."<caption>".'Dangerous Areas for Accidents in Victoria'."</caption>".
		"<tr>" .
		"<th>Area</th>" .
		"<th>Count</th>" .
		"</tr>";	
		foreach ($rows as $row)
		{
			$str3 .= "<tr>";

			foreach ($row['f'] as $field)
			{
				$str3 .= "<td>" . $field['v'] . "</td>";
			}
			$str3 .= "</tr>";
		}
		$str3 .= '</table></div>';
		echo $str3.'<br>';
		
		
		$request->setQuery("SELECT Hours_In_24 as Time, Accidents_Count as Count FROM [assignment2.accidents_in_hours] ORDER BY Count DESC LIMIT 5;");
		$response = $bigquery->jobs->query($projectId, $request);
		$rows = $response->getRows();
		$str4 = "<div id='t4'><table style='width:100%' border=1 cellpadding=10>"."<caption>".'Time of The Day with Most Accidents'."</caption>".
		"<tr>" .
		"<th>Time</th>" .
		"<th>Count</th>" .
		"</tr>";	
		foreach ($rows as $row)
		{
			$str4 .= "<tr>";

			foreach ($row['f'] as $field)
			{
				$str4 .= "<td>" . $field['v'] . "</td>";
			}
			$str4 .= "</tr>";
		}
		$str4 .= '</table></div>';
		echo $str4.'<br>';
		
		
		$request->setQuery("SELECT Road, Count FROM [assignment2.traffic_count_in_road] ORDER BY Count DESC LIMIT 5;");
		$response = $bigquery->jobs->query($projectId, $request);
		$rows = $response->getRows();
		$str5 = "<div id='t5'><table border=1 cellpadding=10>"."<caption>".'Average Vehicle Count in A Month in A Road'."</caption>".
		"<tr>" .
		"<th>Road</th>" .
		"<th>Count</th>" .
		"</tr>";
		foreach ($rows as $row)
		{
			$str5 .= "<tr>";

			foreach ($row['f'] as $field)
			{
				$str5 .= "<td>" . $field['v'] . "</td>";
			}
			$str5 .= "</tr>";
		}
		$str5 .= '</table></div>';
		echo $str5.'<br>';	
		
		$request->setQuery("SELECT Road, Vehicles_Per_Month as Count FROM [assignment2.vehicles_in_road_per_month] WHERE Road LIKE '%FREEWAY%' ORDER BY Count DESC LIMIT 5;");
		$response = $bigquery->jobs->query($projectId, $request);
		$rows = $response->getRows();
		$str6 = "<div id='t6'><table style='width:100%' border=1 cellpadding=10>"."<caption>".'Average Car Flows in Freeways in A Month'."</caption>".
		"<tr>" .
		"<th>Area</th>" .
		"<th>Count</th>" .
		"</tr>";
		foreach ($rows as $row)
		{
			$str6 .= "<tr>";

			foreach ($row['f'] as $field)
			{
				$str6 .= "<td>" . $field['v'] . "</td>";
			}
			$str6 .= "</tr>";
		}
		$str6 .= '</table></div>';
		echo $str6;	
		?>
		<br>
		<a href="https://docs.google.com/spreadsheets/d/1nZuzVpuIgGFgdsWwXTbIw95HhH2HKZXjoi2_TZLP5xU/edit?usp=sharing">Download more results for accidents type, click here.</a><br>
		<a href="https://docs.google.com/spreadsheets/d/1Sgh3Q_foFzVD71VrZ8Cx_XT5GU9WIw4etDou7YBhwTo/edit?usp=sharing">Download more results for ages causing most accidents, click here.</a><br>
		<a href="https://docs.google.com/spreadsheets/d/1dDV09vn6gL2cVunYFjG5plm8LI_NXkNB1BckaEd5mDQ/edit?usp=sharing">Download more results for dangerous areas, click here.</a><br>
		<a href="https://docs.google.com/spreadsheets/d/1CXEHo17146iy31JcfSvFlK6tFf6JeS-gR61R_ecOVSo/edit?usp=sharing">Download more results for time during a day for most accidents, click here.</a><br>
		<a href="https://docs.google.com/spreadsheets/d/1tp7zFgwkrcnB7k-P-zRist5LWaqN497sKXseAw2qM3g/edit?usp=sharing">Download more results for average vehicles count in a month in a road, click here.</a><br>
		<a href="https://docs.google.com/spreadsheets/d/198W4L0rMCgLyY2XJf5swkIiaIPUa3UNEiJjKNIrSUMc/edit?usp=sharing">Download more results for car flows in freeways, click here.</a>
	</main>
	<footer>
    	<div class="copyright">&copy;2016 Ran Lu | RMIT University | School of Computer Science and Information Technology</div>
	</footer>
</body>
</html>
